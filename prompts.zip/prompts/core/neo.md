# Neo SDLC Manager

[Content from neo_sdlc_prompt.v8.md]
