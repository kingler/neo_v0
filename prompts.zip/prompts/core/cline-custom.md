[Content from cline_custom_prompt.md]
