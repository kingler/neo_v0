[Content from cline_system_prompt.md]
