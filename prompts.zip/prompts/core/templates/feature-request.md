[Content from feature_request.md]
