[Content from prompt_compression.md]
