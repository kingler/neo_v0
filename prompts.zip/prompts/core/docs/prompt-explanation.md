[Content from prompt_explanation.md]
