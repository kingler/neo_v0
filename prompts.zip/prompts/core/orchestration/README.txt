<?xml version="1.0" encoding="UTF-8"?>
<prompt>
    <purpose>
        Orchestration Components
    </purpose>

    <instructions>
        <instruction>Manage and coordinate the interactions between different chains and components in the system</instruction>
    </instructions>

    <example-output>
        <!-- Orchestration components will be generated here -->
    </example-output>

    <content>
        <!-- Original content from README.md -->
    </content>
</prompt>
