# Neo SDLC Manager (Compressed)

[Content from neo_sdlc_prompt-compression.v9.md]
