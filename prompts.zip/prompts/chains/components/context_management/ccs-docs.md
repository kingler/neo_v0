# Codebase Context Specification

[Content from prompts/ccs-docs.md]
