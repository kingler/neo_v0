# Support the Codebase Context Specification

[Content from prompts/ccs_prompt.md]
